const notifications = require('../../shared/notifications');

describe('notification helpers', () => {
  test('queues only the next unseen support threshold when exports jump', () => {
    let state = notifications.applyMetricDelta(
      notifications.ensureNotificationState(),
      { exports: 500, batchUrls: 500 }
    );

    state = notifications.queueNextSupportNotification(state, {});

    expect(state.shownSupportThresholds).toEqual([25]);
    expect(state.pendingNotifications).toHaveLength(1);
    expect(state.pendingNotifications[0]).toEqual(
      expect.objectContaining({
        id: 'support-milestone:25',
        milestone: 25,
        type: 'support-milestone'
      })
    );
    expect(notifications.getNextSupportThreshold(state)).toBe(100);
  });

  test('dismissing a support card unlocks the next queued threshold', () => {
    let state = notifications.applyMetricDelta(
      notifications.ensureNotificationState(),
      { exports: 500 }
    );

    state = notifications.queueNextSupportNotification(state, {});
    state = notifications.dismissNotification(state, 'support-milestone:25');
    state = notifications.queueNextSupportNotification(state, {});

    expect(state.shownSupportThresholds).toEqual([25, 100]);
    expect(state.pendingNotifications).toHaveLength(1);
    expect(state.pendingNotifications[0].id).toBe('support-milestone:100');
  });

  test('prioritizes version updates ahead of support cards', () => {
    let state = notifications.applyMetricDelta(
      notifications.ensureNotificationState(),
      { exports: 25 }
    );

    state = notifications.queueNextSupportNotification(state, {});
    state = notifications.queueVersionUpdate(state, {
      previousVersion: '4.1.0',
      currentVersion: '4.1.1',
      highlights: ['Selection capture fix'],
      buyMeACoffeeUrl: notifications.BUY_ME_A_COFFEE_URL,
      releaseNotesUrl: notifications.RELEASES_URL
    });

    const nextNotification = notifications.getNextPendingNotification(state);

    expect(nextNotification).toEqual(
      expect.objectContaining({
        id: 'version-update:4.1.1',
        type: 'version-update',
        currentVersion: '4.1.1'
      })
    );
  });

  test('prioritizes support cards ahead of review requests', () => {
    let state = notifications.applyMetricDelta(
      notifications.ensureNotificationState(),
      { exports: 25 }
    );

    state = notifications.queueReviewRequest(state, {});
    state = notifications.queueNextSupportNotification(state, {});

    expect(notifications.getNextPendingNotification(state)).toEqual(
      expect.objectContaining({
        id: 'support-milestone:25',
        type: 'support-milestone'
      })
    );
  });

  test('queues a support milestone instead of a review request when both are eligible', () => {
    let state = notifications.applyMetricDelta(
      notifications.ensureNotificationState(),
      { exports: 25 }
    );

    state = notifications.queueUsageNotifications(state, {});

    expect(state.shownReviewRequest).toBe(false);
    expect(state.shownSupportThresholds).toEqual([25]);
    expect(state.pendingNotifications).toHaveLength(1);
    expect(state.pendingNotifications[0]).toEqual(
      expect.objectContaining({
        id: 'support-milestone:25',
        type: 'support-milestone'
      })
    );
  });

  test('marks a notification as shown without removing it', () => {
    let state = notifications.queueVersionUpdate(
      notifications.ensureNotificationState(),
      {
        previousVersion: '4.1.0',
        currentVersion: '4.1.1',
        highlights: [],
        buyMeACoffeeUrl: notifications.BUY_ME_A_COFFEE_URL,
        releaseNotesUrl: notifications.RELEASES_URL
      }
    );

    state = notifications.markNotificationShown(state, 'version-update:4.1.1', 12345);

    expect(notifications.getNextPendingNotification(state)?.id).toBe('version-update:4.1.1');
    expect(state.pendingNotifications).toHaveLength(1);
    expect(state.pendingNotifications[0]).toEqual(
      expect.objectContaining({
        id: 'version-update:4.1.1',
        showCount: 1,
        lastShownAt: 12345
      })
    );
  });

  test('shows a never-shown card before one the user already saw and ignored', () => {
    const now = Date.now();
    const state = notifications.ensureNotificationState({
      pendingNotifications: [
        { id: 'version-update:9.9.9', type: 'version-update', createdAt: now, showCount: 1 },
        { id: 'support-milestone:50', type: 'support-milestone', createdAt: now, showCount: 0 }
      ]
    });

    expect(notifications.getNextPendingNotification(state).id).toBe('support-milestone:50');
  });

  test('falls back to an already-shown card when every card has been shown', () => {
    const state = notifications.ensureNotificationState({
      pendingNotifications: [
        { id: 'support-milestone:50', type: 'support-milestone', createdAt: 2, showCount: 1 },
        { id: 'version-update:9.9.9', type: 'version-update', createdAt: 1, showCount: 2 }
      ]
    });

    expect(notifications.getNextPendingNotification(state).id).toBe('version-update:9.9.9');
  });
});
